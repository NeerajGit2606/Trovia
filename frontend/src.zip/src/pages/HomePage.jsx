// src/pages/HomePage.jsx

import React, { useEffect, useState } from 'react'
import { Navbar } from '../features/navigation/components/Navbar'
import { Footer } from '../features/footer/Footer'
import { useDispatch, useSelector } from 'react-redux'
import { resetAddressStatus, selectAddressStatus } from '../features/address/AddressSlice'
import { motion } from 'framer-motion'
import { 
  fetchProductsAsync, 
  selectProducts, 
  selectProductFetchStatus,
  selectProductErrors
} from '../features/products/ProductSlice'
import './HomePage.css'

// ===== SIRF EXISTING IMAGES IMPORT KARO =====
import {
  hero1, hero2, hero3, hero4,
  model1, model2, model3, model4,
  brand1, brand2
} from '../assets'

// ===== PLACEHOLDER IMAGES (ONLINE) =====
const productPlaceholder = 'https://via.placeholder.com/400x400/ff6b81/ffffff?text=PRODUCT'
const brandPlaceholder = 'https://via.placeholder.com/400x400/333333/ffffff?text=BRAND'
const categoryPlaceholder = 'https://via.placeholder.com/400x400/ff9ff3/ffffff?text=CATEGORY'

export const HomePage = () => {
  const dispatch = useDispatch()
  const addressStatus = useSelector(selectAddressStatus)
  const products = useSelector(selectProducts)
  const productStatus = useSelector(selectProductFetchStatus)
  const productErrors = useSelector(selectProductErrors)
  const [currentSlide, setCurrentSlide] = useState(0)

  // ===== SLIDES =====
  const slides = [
    { 
      id: 1, 
      title: 'LUXURY BEAUTY', 
      subtitle: 'JOZY & MARCO', 
      bg: 'linear-gradient(135deg, #ff6b81, #ee5a6f)',
      image: hero1,
      model: model1
    },
    { 
      id: 2, 
      title: 'PINK QUEEN', 
      subtitle: 'Free Shipping Worldwide', 
      bg: 'linear-gradient(135deg, #ff9ff3, #f368e0)',
      image: hero2,
      model: model2
    },
    { 
      id: 3, 
      title: 'ALL NATURAL', 
      subtitle: 'Top Quality Skincare', 
      bg: 'linear-gradient(135deg, #54a0ff, #2e86de)',
      image: hero3,
      model: model3
    },
    { 
      id: 4, 
      title: "L'OREAL PARIS", 
      subtitle: 'Because You\'re Worth It', 
      bg: 'linear-gradient(135deg, #f093fb, #f5576c)',
      image: hero4,
      model: model4
    }
  ]

  // ===== CATEGORIES - ONLINE PLACEHOLDER =====
  const categories = [
    { name: 'FACE', icon: '💄', image: categoryPlaceholder },
    { name: 'EYES', icon: '👁️', image: categoryPlaceholder },
    { name: 'LIPS', icon: '💋', image: categoryPlaceholder },
    { name: 'SKINCARE', icon: '🧴', image: categoryPlaceholder },
    { name: 'MAKEUP', icon: '💄', image: categoryPlaceholder }
  ]

  // ===== BRANDS =====
  const brands = [
    { name: "L'OREAL", image: brand1 || brandPlaceholder },
    { name: 'AERIN', image: brand2 || brandPlaceholder },
    { name: 'FASHIONRAN', image: brandPlaceholder },
    { name: 'VHUGPASI', image: brandPlaceholder }
  ]

  useEffect(() => {
    if (productStatus === 'idle') {
      dispatch(fetchProductsAsync({
        pagination: { page: 1, limit: 4 },
        sort: { sort: 'createdAt', order: -1 }
      }))
    }
  }, [dispatch, productStatus])

  useEffect(() => {
    if (addressStatus === 'fulfilled') {
      dispatch(resetAddressStatus())
    }
  }, [addressStatus, dispatch])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 4000)
    return () => clearInterval(timer)
  }, [slides.length])

  if (productStatus === 'pending') {
    return (
      <>
        <Navbar isProductList={true} />
        <div className="loading-container">
          <div className="loader"></div>
          <p>Loading Products...</p>
        </div>
        <Footer />
      </>
    )
  }

  if (productStatus === 'rejected') {
    return (
      <>
        <Navbar isProductList={true} />
        <div className="error-container">
          <div className="error-icon">⚠️</div>
          <h2>Failed to Load Products</h2>
          <p>{productErrors?.message || 'Something went wrong. Please try again.'}</p>
          <button onClick={() => {
            dispatch(fetchProductsAsync({
              pagination: { page: 1, limit: 4 },
              sort: { sort: 'createdAt', order: -1 }
            }))
          }}>
            Try Again
          </button>
        </div>
        <Footer />
      </>
    )
  }

  const featuredProducts = products || []

  return (
    <>
      <Navbar isProductList={true} />

      {/* ===== HERO SLIDER ===== */}
      <section className="hero-slider">
        {slides.map((slide, index) => (
          <motion.div
            key={slide.id}
            className={`slide ${index === currentSlide ? 'active' : ''}`}
            style={{ background: slide.bg }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ 
              opacity: index === currentSlide ? 1 : 0,
              scale: index === currentSlide ? 1 : 0.9
            }}
            transition={{ duration: 0.8 }}
          >
            <div className="slide-content">
              <motion.span
                className="slide-badge"
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                NEW COLLECTION
              </motion.span>
              <motion.h1
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                {slide.title}
              </motion.h1>
              <motion.h2
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                {slide.subtitle}
              </motion.h2>
              <motion.button
                className="shop-now-btn"
                whileHover={{ scale: 1.1, boxShadow: '0 20px 60px rgba(0,0,0,0.3)' }}
                whileTap={{ scale: 0.95 }}
                onClick={() => window.location.href = '/shop'}
              >
                Shop Now →
              </motion.button>
            </div>
            <div className="slide-image-container">
              <motion.img 
                src={slide.model} 
                alt={slide.title}
                className="slide-model"
                initial={{ scale: 1.2, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1, delay: 0.3 }}
              />
              <motion.img 
                src={slide.image} 
                alt={slide.title}
                className="slide-product"
                initial={{ y: 100, opacity: 0, rotate: 10 }}
                animate={{ y: 0, opacity: 1, rotate: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              />
            </div>
          </motion.div>
        ))}
        <div className="slide-dots">
          {slides.map((_, index) => (
            <span
              key={index}
              className={`dot ${index === currentSlide ? 'active' : ''}`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      {/* ===== BRANDS ===== */}
      <section className="brands-section">
        <h2 className="section-title">✨ TOP BEAUTY BRANDS</h2>
        <div className="brands-grid">
          {brands.map((brand, index) => (
            <motion.div
              key={brand.name}
              className="brand-card"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.1 }}
            >
              <img src={brand.image} alt={brand.name} />
              <h3>{brand.name}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ===== CATEGORIES ===== */}
      <section className="categories-section">
        <h2 className="section-title">🌸 SHOP BY CATEGORY</h2>
        <div className="categories-grid">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.name}
              className="category-card"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.1, boxShadow: '0 20px 40px rgba(0,0,0,0.2)' }}
            >
              <div className="category-image">
                <img src={cat.image} alt={cat.name} />
              </div>
              <span className="category-icon">{cat.icon}</span>
              <h3>{cat.name}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ===== PRODUCTS ===== */}
      <section className="featured-products">
        <h2 className="section-title">🔥 NEW COLLECTION</h2>
        {featuredProducts.length === 0 ? (
          <div className="no-products">
            <p>No products available. Please add products to the database.</p>
          </div>
        ) : (
          <div className="product-grid">
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product._id || product.id}
                className="product-card"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ 
                  scale: 1.05,
                  boxShadow: '0 20px 60px rgba(0,0,0,0.15)'
                }}
              >
                <div className="product-image">
                  <img 
                    src={product.image || productPlaceholder} 
                    alt={product.name || product.title}
                    onError={(e) => {
                      e.target.src = productPlaceholder
                    }}
                  />
                  <motion.div 
                    className="product-overlay"
                    whileHover={{ opacity: 1 }}
                  >
                    <button onClick={() => window.location.href = `/product/${product._id || product.id}`}>
                      Quick View
                    </button>
                  </motion.div>
                </div>
                <h3>{product.name || product.title}</h3>
                <p className="product-price">${product.price}</p>
                <motion.button 
                  className="add-to-cart"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    alert(`Added ${product.name || product.title} to cart!`)
                  }}
                >
                  Add to Cart
                </motion.button>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      <Footer />
    </>
  )
}